package com.example.gst_calculator

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
